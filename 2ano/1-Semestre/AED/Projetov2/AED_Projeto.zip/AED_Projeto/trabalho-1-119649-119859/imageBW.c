/// imageBW - A simple image processing module for BW images
///           represented using run-length encoding (RLE)
///
/// This module is part of a programming project
/// for the course AED, DETI / UA.PT
///
/// You may freely use and modify this code, at your own risk,
/// as long as you give proper credit to the original and subsequent authors.
///
/// The AED Team <jmadeira@ua.pt, jmr@ua.pt, ...>
/// 2024

// Student authors (fill in below):
// NMec:  119649
// Name:  Miguel Santos
// NMec:  119859
// Name:  João Leite
//
// Date:  28/11/2024
//

#include "imageBW.h"

#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <time.h>

#include "instrumentation.h"

// The data structure
//
// A BW image is stored in a structure containing 3 fields:
// Two integers store the image width and height.
// The other field is a pointer to an array that stores the pointers
// to the RLE compressed image rows.
//
// Clients should use images only through variables of type Image,
// which are pointers to the image structure, and should not access the
// structure fields directly.

// Constant value --- Use them throughout your code
// const uint8 BLACK = 1;  // Black pixel value, defined on .h
// const uint8 WHITE = 0;  // White pixel value, defined on .h
const int EOR = -1; // Stored as the last element of a RLE row

// Internal structure for storing RLE BW images
struct image
{
  uint32 width;
  uint32 height;
  int **row; // pointer to an array of pointers referencing the compressed rows
};

// This module follows "design-by-contract" principles.
// Read `Design-by-Contract.md` for more details.

/// Error handling functions

// In this module, only functions dealing with memory allocation or
// file (I/O) operations use defensive techniques.
// When one of these functions fails,
// it immediately prints an error and exits the program.
// This fail-fast approach to error handling is simpler for the programmer.

// Use the following function to check a condition
// and exit if it fails.

// Check a condition and if false, print failmsg and exit.
static void check(int condition, const char *failmsg)
{
  if (!condition)
  {
    perror(failmsg);
    exit(errno || 255);
  }
}

/// Init Image library.  (Call once!)
/// Currently, simply calibrate instrumentation and set names of counters.
void ImageInit(void)
{ ///
  InstrCalibrate();
  InstrName[0] = "pixmem"; // InstrCount[0] will count pixel array acesses
  // Name other counters here...
}

// Macros to simplify accessing instrumentation counters:
#define PIXMEM InstrCount[0]
// Add more macros here...

// TIP: Search for PIXMEM or InstrCount to see where it is incremented!

/// Auxiliary (static) functions

/// Create the header of an image data structure
/// And allocate the array of pointers to RLE rows
static Image AllocateImageHeader(uint32 width, uint32 height)
{
  assert(width > 0 && height > 0);
  Image newHeader = malloc(sizeof(struct image));
  check(newHeader != NULL, "malloc");

  newHeader->width = width;
  newHeader->height = height;

  // Allocating the array of pointers to RLE rows
  newHeader->row = malloc(height * sizeof(int *));
  check(newHeader->row != NULL, "malloc");

  return newHeader;
}

/// Allocate an array to store a RLE row with n elements
static int *AllocateRLERowArray(uint32 n)
{
  assert(n > 2);
  int *newArray = malloc(n * sizeof(int));
  check(newArray != NULL, "malloc");

  return newArray;
}

/// Compute the number of runs of a non-compressed (RAW) image row
static uint32 GetNumRunsInRAWRow(uint32 image_width, const uint8 *RAW_row)
{
  assert(image_width > 0);
  assert(RAW_row != NULL);

  // How many runs?
  uint32 num_runs = 1;
  for (uint32 i = 1; i < image_width; i++)
  {
    if (RAW_row[i] != RAW_row[i - 1])
    {
      num_runs++;
    }
  }

  return num_runs;
}

/// Get the number of runs of a compressed RLE image row
static uint32 GetNumRunsInRLERow(const int *RLE_row)
{
  assert(RLE_row != NULL);

  // Go through the RLE_row until EOR is found
  // Discard RLE_row[0], since it is a pixel color

  uint32 num_runs = 0;
  uint32 i = 1;
  while (RLE_row[i] != EOR)
  {
    num_runs++;
    i++;
  }

  return num_runs;
}

/// Get the number of elements of an array storing a compressed RLE image row
static uint32 GetSizeRLERowArray(const int *RLE_row)
{
  assert(RLE_row != NULL);

  // Go through the array until EOR is found
  uint32 i = 0;
  while (RLE_row[i] != EOR)
  {
    i++;
  }

  return (i + 1);
}

/// Compress into RLE format a RAW image row
/// Allocates and returns the array storing the image row in RLE format
static int *CompressRow(uint32 image_width, const uint8 *RAW_row)
{
  assert(image_width > 0);
  assert(RAW_row != NULL);

  // How many runs?
  uint32 num_runs = GetNumRunsInRAWRow(image_width, RAW_row);

  // Allocate the RLE row array
  int *RLE_row = malloc((num_runs + 2) * sizeof(int));
  check(RLE_row != NULL, "malloc");

  // Go through the RAW_row
  RLE_row[0] = (int)RAW_row[0]; // Initial pixel value
  uint32 index = 1;
  int num_pixels = 1;
  for (uint32 i = 1; i < image_width; i++)
  {
    if (RAW_row[i] != RAW_row[i - 1])
    {
      RLE_row[index++] = num_pixels;
      num_pixels = 0;
    }
    num_pixels++;
  }
  RLE_row[index++] = num_pixels;
  RLE_row[index] = EOR; // Reached the end of the row

  return RLE_row;
}

static uint8 *UncompressRow(uint32 image_width, const int *RLE_row)
{
  assert(image_width > 0);
  assert(RLE_row != NULL);

  // The uncompressed row
  uint8 *row = (uint8 *)malloc(image_width * sizeof(uint8));
  check(row != NULL, "malloc");

  // Go through the RLE_row until EOR is found
  int pixel_value = RLE_row[0];
  uint32 i = 1;
  uint32 dest_i = 0;
  while (RLE_row[i] != EOR)
  {
    // For each run
    for (int aux = 0; aux < RLE_row[i]; aux++)
    {
      row[dest_i++] = (uint8)pixel_value;
    }
    // Next run
    i++;
    pixel_value ^= 1;
  }

  return row;
}

// Add your auxiliary functions here...

/// Image management functions

/// Create a new BW image, either BLACK or WHITE.
///   width, height : the dimensions of the new image.
///   val: the pixel color (BLACK or WHITE).
/// Requires: width and height must be non-negative, val is either BLACK or
/// WHITE.
///
/// On success, a new image is returned.
/// (The caller is responsible for destroying the returned image!)
Image ImageCreate(uint32 width, uint32 height, uint8 val)
{
  assert(width > 0 && height > 0);
  assert(val == WHITE || val == BLACK);

  Image newImage = AllocateImageHeader(width, height);

  // All image pixels have the same value
  int pixel_value = (int)val;

  // Creating the image rows, each row has just 1 run of pixels
  // Each row is represented by an array of 3 elements [value,length,EOR]
  for (uint32 i = 0; i < height; i++)
  {
    newImage->row[i] = AllocateRLERowArray(3);
    newImage->row[i][0] = pixel_value;
    newImage->row[i][1] = (int)width;
    newImage->row[i][2] = EOR;
  }

  return newImage;
}

/// Create a new BW image, with a perfect CHESSBOARD pattern.
///   width, height : the dimensions of the new image.
///   square_edge : the lenght of the edges of the sqares making up the
///   chessboard pattern.
///   first_value: the pixel color (BLACK or WHITE) of the
///   first image pixel.
/// Requires: width and height must be non-negative, val is either BLACK or
/// WHITE.
/// Requires: for the squares, width and height must be multiples of the
/// edge lenght of the squares
///
/// On success, a new image is returned.
/// (The caller is responsible for destroying the returned image!)Image ImageCreateChessboard(uint32 width, uint32 height, uint32 square_edge, uint8 first_value) {
// Ensure that the input parameters are valid

Image ImageCreateChessboard(uint32 width, uint32 height, uint32 square_edge, uint8 first_value)
{
  assert(width > 0 && height > 0);
  assert(square_edge > 0);
  assert(first_value == WHITE || first_value == BLACK);
  assert(width % square_edge == 0 && height % square_edge == 0);

  // Allocate memory for the entire image at once
  Image chessboard = AllocateImageHeader(width, height);

  // Initialize the current row value with the first_value
  uint8 current_row_value = first_value;

  // Calculate the number of runs (squares) in each row
  uint32 num_runs = width / square_edge;

  // Process each row of the image
  for (uint32 i = 0; i < height; i++)
  {
    // Allocate memory for the current row
    chessboard->row[i] = AllocateRLERowArray(2 * num_runs + 1);

    // Set the first pixel value of the current row
    chessboard->row[i][0] = current_row_value;

    // Process each run (square) in the current row
    for (uint32 j = 1; j < num_runs; j++)
    {
      // Set the run length (width) of the current square
      chessboard->row[i][j] = square_edge;

      // Switch the current row value (color) for the next square
      current_row_value ^= 1;

      // Set the end pixel value of the current square
      chessboard->row[i][j + 1] = current_row_value - 1;

      // Reset the current row value to the first value for the next square
      current_row_value = first_value;
    }

    // Set the end of row marker
    chessboard->row[i][2 * num_runs] = EOR;

    // If the current row is at the end of a square_edge x square_edge block,
    // switch the first value for the next block
    if ((i + 1) % square_edge == 0)
    {
      first_value ^= 1;
      current_row_value = first_value;
    }
  }

  // Return the newly created chessboard image
  return chessboard;
}

/// Destroy the image pointed to by (*imgp).
///   imgp : address of an Image variable.
/// If (*imgp)==NULL, no operation is performed.
/// Ensures: (*imgp)==NULL.
/// Should never fail.
void ImageDestroy(Image *imgp)
{
  assert(imgp != NULL);

  Image img = *imgp;

  for (uint32 i = 0; i < img->height; i++)
  {
    free(img->row[i]);
  }
  free(img->row);
  free(img);

  *imgp = NULL;
}

/// Printing on the console

/// Output the raw BW image
void ImageRAWPrint(const Image img)
{
  assert(img != NULL);

  printf("width = %d height = %d\n", img->width, img->height);
  printf("RAW image:\n");

  // Print the pixels of each image row
  for (uint32 i = 0; i < img->height; i++)
  {
    // The value of the first pixel in the current row
    int pixel_value = img->row[i][0];
    for (uint32 j = 1; img->row[i][j] != EOR; j++)
    {
      // Print the current run of pixels
      for (int k = 0; k < img->row[i][j]; k++)
      {
        printf("%d", pixel_value);
      }
      // Switch (XOR) to the pixel value for the next run, if any
      pixel_value ^= 1;
    }
    // At current row end
    printf("\n");
  }
  printf("\n");
}

/// Output the compressed RLE image
void ImageRLEPrint(const Image img)
{
  assert(img != NULL);

  printf("width = %d height = %d\n", img->width, img->height);
  printf("RLE encoding:\n");

  // Print the compressed rows information
  for (uint32 i = 0; i < img->height; i++)
  {
    uint32 j;
    for (j = 0; img->row[i][j] != EOR; j++)
    {
      printf("%d ", img->row[i][j]);
    }
    printf("%d\n", img->row[i][j]);
  }
  printf("\n");
}

/// PBM BW file operations

// See PBM format specification: http://netpbm.sourceforge.net/doc/pbm.html

// Auxiliary function
static void unpackBits(int nbytes, const uint8 bytes[], uint8 raw_row[])
{
  // bitmask starts at top bit
  int offset = 0;
  uint8 mask = 1 << (7 - offset);
  while (offset < 8)
  { // or (mask > 0)
    for (int b = 0; b < nbytes; b++)
    {
      raw_row[8 * b + offset] = (bytes[b] & mask) != 0;
    }
    mask >>= 1;
    offset++;
  }
}

// Auxiliary function
static void packBits(int nbytes, uint8 bytes[], const uint8 raw_row[])
{
  // bitmask starts at top bit
  int offset = 0;
  uint8 mask = 1 << (7 - offset);
  while (offset < 8)
  { // or (mask > 0)
    for (int b = 0; b < nbytes; b++)
    {
      if (offset == 0)
        bytes[b] = 0;
      bytes[b] |= raw_row[8 * b + offset] ? mask : 0;
    }
    mask >>= 1;
    offset++;
  }
}

// Match and skip 0 or more comment lines in file f.
// Comments start with a # and continue until the end-of-line, inclusive.
// Returns the number of comments skipped.
static int skipComments(FILE *f)
{
  char c;
  int i = 0;
  while (fscanf(f, "#%*[^\n]%c", &c) == 1 && c == '\n')
  {
    i++;
  }
  return i;
}

/// Load a raw PBM file.
/// Only binary PBM files are accepted.
/// On success, a new image is returned.
/// (The caller is responsible for destroying the returned image!)
Image ImageLoad(const char *filename)
{ ///
  int w, h;
  char c;
  FILE *f = NULL;
  Image img = NULL;

  check((f = fopen(filename, "rb")) != NULL, "Open failed");
  // Parse PBM header
  check(fscanf(f, "P%c ", &c) == 1 && c == '4', "Invalid file format");
  skipComments(f);
  check(fscanf(f, "%d ", &w) == 1 && w >= 0, "Invalid width");
  skipComments(f);
  check(fscanf(f, "%d", &h) == 1 && h >= 0, "Invalid height");
  check(fscanf(f, "%c", &c) == 1 && isspace(c), "Whitespace expected");

  // Allocate image
  img = AllocateImageHeader(w, h);

  // Read pixels
  int nbytes = (w + 8 - 1) / 8; // number of bytes for each row
  // using VLAs...
  uint8 bytes[nbytes];
  uint8 raw_row[nbytes * 8];
  for (uint32 i = 0; i < img->height; i++)
  {
    check(fread(bytes, sizeof(uint8), nbytes, f) == (size_t)nbytes,
          "Reading pixels");
    unpackBits(nbytes, bytes, raw_row);
    img->row[i] = CompressRow(w, raw_row);
  }

  fclose(f);
  return img;
}

/// Save image to PBM file.
/// On success, returns nonzero.
/// On failure, returns 0, and
/// a partial and invalid file may be left in the system.
int ImageSave(const Image img, const char *filename)
{ ///
  assert(img != NULL);
  int w = img->width;
  int h = img->height;
  FILE *f = NULL;

  check((f = fopen(filename, "wb")) != NULL, "Open failed");
  check(fprintf(f, "P4\n%d %d\n", w, h) > 0, "Writing header failed");

  // Write pixels
  int nbytes = (w + 8 - 1) / 8; // number of bytes for each row
  // using VLAs...
  uint8 bytes[nbytes];
  // unit8 raw_row[nbytes*8];
  for (uint32 i = 0; i < img->height; i++)
  {
    // UncompressRow...
    uint8 *raw_row = UncompressRow(nbytes * 8, img->row[i]);
    // Fill padding pixels with WHITE
    memset(raw_row + w, WHITE, nbytes * 8 - w);
    packBits(nbytes, bytes, raw_row);
    check(fwrite(bytes, sizeof(uint8), nbytes, f) == (size_t)nbytes,
          "Writing pixels failed");
    free(raw_row);
  }

  // Cleanup
  fclose(f);
  return 0;
}

/// Information queries

/// Get image width
int ImageWidth(const Image img)
{
  assert(img != NULL);
  return img->width;
}

/// Get image height
int ImageHeight(const Image img)
{
  assert(img != NULL);
  return img->height;
}

/// Image comparison

int ImageIsEqual(const Image img1, const Image img2)
{
  // Ensure both input images exist and are not NULL
  assert(img1 != NULL && img2 != NULL);

  // Check if the dimensions of both images match
  // If the dimensions are not equal, the images cannot be equal
  if (img1->width != img2->width || img1->height != img2->height)
  {
    return 0; // Images are not equal
  }

  // Iterate through each row of the images
  for (uint32 i = 0; i < img1->height; i++)
  {
    // Get the current row from both images
    const int *row1 = img1->row[i]; // Row from the first image
    const int *row2 = img2->row[i]; // Row from the second image

    // Compare the current row from both images
    // If the rows are not equal, the images cannot be equal
    if (row1 != row2)
    {
      return 0; // Images are not equal
    }
  }

  // If we've gone through all the rows and found no differences,
  // the images must be equal
  return 1; // Images are equal
}

int ImageIsDifferent(const Image img1, const Image img2)
{
  assert(img1 != NULL && img2 != NULL);
  return !ImageIsEqual(img1, img2);
}

/// Boolean Operations on image pixels

/// These functions apply boolean operations to images,
/// returning a new image as a result.
///
/// Operand images are left untouched and must be of the same size.
///
/// On success, a new image is returned.
/// (The caller is responsible for destroying the returned image!)

Image ImageNEG(const Image img)
{
  assert(img != NULL);

  uint32 width = img->width;
  uint32 height = img->height;

  Image newImage = AllocateImageHeader(width, height);

  // Directly copying the rows, one by one
  // And changing the value of row[i][0]

  for (uint32 i = 0; i < height; i++)
  {
    uint32 num_elems = GetSizeRLERowArray(img->row[i]); // Number of elements in the row
    newImage->row[i] = AllocateRLERowArray(num_elems);
    memcpy(newImage->row[i], img->row[i], num_elems * sizeof(int));
    newImage->row[i][0] ^= 1; // Just negate the value of the first pixel run
  }

  return newImage;
}
Image ImageAND(const Image img1, const Image img2)
{
  assert(img1 != NULL && img2 != NULL);

  Image img = AllocateImageHeader(img1->width, img1->height);

  InstrCount[PIXMEM]++;

  for (uint32 i = 0; i < img->height; i++)
  {
    uint32 *row1 = (uint32 *)img1->row[i];
    uint32 *row2 = (uint32 *)img2->row[i];

    uint32 *resultRow = AllocateRLERowArray(img1->width + 2);

    uint8 color1 = (uint8)row1[0];
    uint8 color2 = (uint8)row2[0];

    uint32 index1 = 1, index2 = 1, resultIndex = 0;

    resultRow[resultIndex++] = color1 & color2;
    resultRow[resultIndex] = 0;

    uint8 oldColor = (uint8)resultRow[0];

    uint32 runLength1 = row1[index1];
    uint32 runLength2 = row2[index2];

    while ((row1[index1] != (uint32)-1) && (row2[index2] != (uint32)-1))
    {
      IncrementOperationCount();

      uint32 minRunLength = (runLength1 <= runLength2) ? runLength1 : runLength2;
      uint8 newColor = color1 & color2;

      // Add to the new image
      if (newColor == oldColor)
      {
        resultRow[resultIndex] += minRunLength; // Extend the current run
      }
      else
      {
        resultRow[++resultIndex] = minRunLength; // Add new run length
        oldColor = newColor;
      }

      runLength1 -= minRunLength;
      runLength2 -= minRunLength;

      // Move to the next run if the current run is exhausted
      if (runLength1 == 0)
      {
        index1++;
        runLength1 = row1[index1];
        color1 = 1 - color1;
      }
      if (runLength2 == 0)
      {
        index2++;
        runLength2 = row2[index2];
        color2 = 1 - color2;
      }
    }
    resultRow[++resultIndex] = (uint32)EOR; // End of row marker

    uint32 *newRow = AllocateRLERowArray(resultIndex + 1);

    memcpy(newRow, resultRow, (resultIndex + 1) * sizeof(uint32));

    free(resultRow);

    img->row[i] = newRow;
  }

  return img;
}

Image ImageOR(const Image img1, const Image img2)
{
  assert(img1 != NULL && img2 != NULL);
  assert(img1 != NULL && img2 != NULL);
  assert(img1->width == img2->width && img1->height == img2->height);
  assert(img1->row[0] != NULL && img2->row[0] != NULL);

  Image newImage = AllocateImageHeader(img1->width, img1->height);

  for (uint32 i = 0; i < img1->height; i++)
  {
    uint8 *row1 = UncompressRow(img1->width, img1->row[i]);
    uint8 *row2 = UncompressRow(img2->width, img2->row[i]);

    uint8 *newRow = (uint8 *)malloc(img1->width * sizeof(uint8));
    for (uint32 j = 0; j < img1->width; j++)
    {
      newRow[j] = row1[j] || row2[j];
    }

    newImage->row[i] = CompressRow(newImage->width, newRow);
  }

  return newImage;
}

Image ImageXOR(Image img1, Image img2)
{
  assert(img1 != NULL && img2 != NULL);
  assert(img1->width == img2->width && img1->height == img2->height);
  assert(img1->row[0] != NULL && img2->row[0] != NULL);

  Image newImage = AllocateImageHeader(img1->width, img1->height);

  for (uint32 i = 0; i < img1->height; i++)
  {
    uint8 *row1 = UncompressRow(img1->width, img1->row[i]);
    uint8 *row2 = UncompressRow(img2->width, img2->row[i]);

    uint8 *newRow = (uint8 *)malloc(img1->width * sizeof(uint8));

    for (uint32 j = 0; j < img1->width; j++)
    {
      newRow[j] = row1[j] ^ row2[j];
    }

    newImage->row[i] = CompressRow(newImage->width, newRow);

    free(row1);
    free(row2);
    free(newRow);
  }

  return newImage;
}
/// Geometric transformations

/// These functions apply geometric transformations to an image,
/// returning a new image as a result.
///
/// On success, a new image is returned.
/// (The caller is responsible for destroying the returned image!)

/// Mirror an image = flip top-bottom.
/// Returns a mirrored version of the image.
/// Ensures: The original img is not modified.
///
/// On success, a new image is returned.
/// (The caller is responsible for destroying the returned image!)
Image ImageHorizontalMirror(const Image img)
{
  assert(img != NULL);

  Image result = AllocateImageHeader(img->width, img->height);

  for (uint32 i = 0; i < img->height; i++)
  {
    result->row[img->height - 1 - i] = AllocateRLERowArray(GetSizeRLERowArray(img->row[i]));
    memcpy(result->row[img->height - 1 - i], img->row[i], GetSizeRLERowArray(img->row[i]) * sizeof(int));
  }

  return result;
}

/// Mirror an image = flip left-right.
/// Returns a mirrored version of the image.
/// Ensures: The original img is not modified.
///
/// On success, a new image is returned.
/// (The caller is responsible for destroying the returned image!)

Image ImageVerticalMirror(const Image img)
{
  // Ensure the input image is valid
  assert(img != NULL);

  // Get the dimensions of the input image
  uint32 width = img->width;
  uint32 height = img->height;

  // Create a new image with the same dimensions as the input
  Image newImage = AllocateImageHeader(width, height);

  // Process each row of the image
  for (uint32 i = 0; i < height; i++)
  {
    // Decompress the current row of the original image
    uint8 *originalRow = UncompressRow(width, img->row[i]);

    // Allocate memory for the mirrored row
    uint8 *mirroredRow = (uint8 *)malloc(width * sizeof(uint8));

    // Mirror the pixels in the row
    for (uint32 j = 0; j < width; j++)
    {
      // Copy pixels from right to left
      // e.g., for a row of 5 pixels:
      // Original: [0][1][2][3][4]
      // Mirrored: [4][3][2][1][0]
      mirroredRow[j] = originalRow[width - 1 - j];
    }

    // Compress the mirrored row and store it in the new image
    newImage->row[i] = CompressRow(width, mirroredRow);

    // Free the temporary memory used for processing this row
    free(originalRow);
    free(mirroredRow);
  }

  // Return the newly created mirrored image
  return newImage;
}

/// Replicate img2 at the bottom of imag1, creating a larger image
/// Requires: the width of the two images must be the same.
/// Returns the new larger image.
/// Ensures: The original images are not modified.
///
/// On success, a new image is returned.
/// (The caller is responsible for destroying the returned image!)
Image ImageReplicateAtBottom(const Image img1, const Image img2)
{
  assert(img1 != NULL && img2 != NULL);
  assert(img1->width == img2->width);

  // Calculate dimensions of the new image
  // The width remains the same, but the height is the sum of both images' heights
  uint32 new_width = img1->width;
  uint32 new_height = img1->height + img2->height;

  // Allocate memory for the new image
  // This creates the structure for the new image with the calculated dimensions
  Image newImage = AllocateImageHeader(new_width, new_height);

  // Iterate through each row of the new image
  for (uint32 i = 0; i < new_height; i++)
  {
    if (i < img1->height)
    {
      // For rows within img1's height, copy from img1
      // This copies the entire first image into the top part of the new image
      uint32 size = GetSizeRLERowArray(img1->row[i]);
      newImage->row[i] = AllocateRLERowArray(size);
      memcpy(newImage->row[i], img1->row[i], size * sizeof(int));
    }
    else
    {
      // For rows beyond img1's height, copy from img2
      // This copies the second image into the bottom part of the new image
      // We adjust the index for img2 by subtracting img1's height
      uint32 size = GetSizeRLERowArray(img2->row[i - img1->height]);
      newImage->row[i] = AllocateRLERowArray(size);
      memcpy(newImage->row[i], img2->row[i - img1->height], size * sizeof(int));
    }
  }

  // Return the newly created image
  return newImage;
}

/// Replicate img2 to the right of imag1, creating a larger image
/// Requires: the height of the two images must be the same.
/// Returns the new larger image.
/// Ensures: The original images are not modified.
///
/// On success, a new image is returned.
/// (The caller is responsible for destroying the returned image!)
Image ImageReplicateAtRight(const Image img1, const Image img2)
{
  assert(img1 != NULL && img2 != NULL);
  assert(img1->height == img2->height);

  uint32 new_width = img1->width + img2->width;
  uint32 new_height = img1->height;

  Image newImage = AllocateImageHeader(new_width, new_height);

  for (uint32 i = 0; i < new_height; i++)
  {
    uint8 *row1 = UncompressRow(img1->width, img1->row[i]);
    uint8 *row2 = UncompressRow(img2->width, img2->row[i]);

    uint8 *newRow = (uint8 *)malloc(new_width * sizeof(uint8));
    for (uint32 j = 0; j < img1->width; j++)
    {
      newRow[j] = row1[j];
    }
    for (uint32 j = 0; j < img2->width; j++)
    {
      newRow[img1->width + j] = row2[j];
    }

    newImage->row[i] = CompressRow(new_width, newRow);
    free(row1);
    free(row2);
    free(newRow);
  }

  return newImage;
}
